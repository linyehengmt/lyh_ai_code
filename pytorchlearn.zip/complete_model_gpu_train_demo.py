import torch.utils.data
import torchvision.datasets
from torch import nn
from torch.utils.tensorboard import SummaryWriter

#定义设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

#准备数据集
train_dataset = torchvision.datasets.CIFAR10('./dataset', train=True,
                                         transform=torchvision.transforms.ToTensor(), download=True)
test_dataset = torchvision.datasets.CIFAR10('./dataset', train=False,
                                         transform=torchvision.transforms.ToTensor(), download=True)

#输出长度
train_dataset_len = len(train_dataset)
test_dataset_len = len(test_dataset)
print('len(train_dataset):{}'.format(train_dataset_len))
print('len(test_dataset):{}'.format(test_dataset_len))

#dataloader
train_dataloader = torch.utils.data.DataLoader(train_dataset, 64)
test_dataloader = torch.utils.data.DataLoader(test_dataset, 64)

#tensorboard
writer = SummaryWriter('./logs_train_loss')

#搭建CIFAR10的网络
class Tudui(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Conv2d(3, 32, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 32, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(64*4*4, 64),
            nn.Linear(64, 10)
        )
    def forward(self, x):
        x = self.model(x)
        return x

tudui = Tudui()
tudui.to(device)

#损失函数
loss_func = nn.CrossEntropyLoss()
loss_func.to(device)

#优化器
learning_rate = 0.01
optimizer = torch.optim.SGD(tudui.parameters(), lr=learning_rate)

#设置训练参数
epoch = 10
#实时训练次数
train_step = 0
#实时测试次数
test_step = 0



for i in range(epoch):
    print("---------epoch {} start---------".format(i+1))
    #训练
    tudui.train()
    for data in train_dataloader:
        imgs, targets = data
        imgs = imgs.to(device)
        targets = targets.to(device)
        outputs = tudui(imgs)
        #计算损失
        loss = loss_func(outputs, targets)

        #优化模型
        optimizer.zero_grad() #梯度清零
        loss.backward() #反向传播得出梯度
        optimizer.step() #更新梯度

        #累计次数,训练不需要累计loss
        train_step += 1

        if train_step % 100 == 0:
            print("train times:{}, loss:{}".format(train_step, loss.item()))
            # tensorboard
            writer.add_scalar('train_loss', loss.item(), train_step)

    #测试
    tudui.eval()
    test_total_loss = 0
    total_accuracy = 0
    #使用with torch.no_grad,表明当前计算不需要反向传播，使用之后，强制后边的内容不进行计算图的构建
    with torch.no_grad():
        for data in test_dataloader:
            imgs, targets = data
            imgs = imgs.to(device)
            targets = targets.to(device)
            outputs = tudui(imgs)
            loss = loss_func(outputs, targets)

            test_total_loss += loss.item()
            accuracy = (outputs.argmax(1)==targets).sum()
            total_accuracy += accuracy

    #每次epoch后统计
    print("epoch {} test_loss:{}".format((i+1), test_total_loss))
    print("epoch {} test_acc:{}".format((i+1), total_accuracy/test_dataset_len))
    # tensorboard
    test_step += 1
    writer.add_scalar('test_total_loss', test_total_loss, test_step)
    writer.add_scalar('test_acc', total_accuracy/test_dataset_len, test_step)

    #每次epoch后保存模型,这里采用方式一
    torch.save(tudui, 'tudui_epoch{}'.format(i+1))