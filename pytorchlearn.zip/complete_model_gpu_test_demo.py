import torch
from PIL import Image
from torch import nn
from torchvision import transforms

img_path = './test_data/dog.png'

image = Image.open(img_path)
image = image.convert('RGB')

trans_tool = transforms.Compose([
    transforms.ToTensor(),
    transforms.Resize((32, 32))
])

print(image.size)
image = trans_tool(image)
image = torch.reshape(image, (1, 3, 32, 32))
print(image.shape) #torch.Size([3, 32, 32])


class Tudui(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Conv2d(3, 32, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 32, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(64*4*4, 64),
            nn.Linear(64, 10)
        )
    def forward(self, x):
        x = self.model(x)
        return x
#具体来说，map_location参数是用于重定向，比如此前模型的参数是在cpu中的，我们希望将其加载到cuda:0中。
model = torch.load('./tudui_epoch4', map_location='cpu')

model.eval()
with torch.no_grad():
    output = model(image)

print(output.argmax(1))

